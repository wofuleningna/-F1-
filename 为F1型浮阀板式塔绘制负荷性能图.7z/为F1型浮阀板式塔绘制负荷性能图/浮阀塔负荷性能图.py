import win32com.client as win32
import os
import tomllib
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from openpyxl import Workbook

with open(os.path.abspath("config.toml"), "rb") as f:
    config = tomllib.load(f)

# 易变配置
bkp_path = config["bkp_path"]
block = config["block"]
is_2_overflow = config["is_2_overflow"]             # 当塔径为2.2米或2.4米时是否采取双溢流塔板，推荐选取
receiving_pan = config["receiving_pan"]             # 受液盘形状
f_o = config["f_o"]                                 # 阀孔动能因数
f_1 = config["f_1"]                                 # 最大液泛率，用以控制雾沫夹带线a
k_s = config["k_s"]                                 # 系统因数
phi_2 = config["phi_2"]                             # 相对泡沫密度
tao = config["tao"]                                 # 液体在降液管中的最小停留时间
choose_fog_line = config["choose_fog_line"]         # 雾沫夹带线选择哪一条
available_d =np.array([0.6, 0.7, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2, 2.4,
                       2.6, 2.8, 3.0, 3.2, 3.4, 3.6, 3.8, 4.2])        # 允许的直径系列
n_stage = 0                                         # 这块后续会读取，如果不先定义，后面声明全局变量那块pycharm会给你画个淡黄线
feed_stage = 0
# 连接aspen
aspen = win32.Dispatch('Apwn.Document.{}'.format(40.0))
aspen.InitFromArchive2(os.path.abspath(f"{bkp_path}"))
# 统一度量衡
aspen.Tree.FindNode("/Data/Setup/Global/Input/INSET").Value = "SI"
aspen.Engine.Run2()

def set_internal():

    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Subobjects/Column Internals").Elements.Add("INT-1")
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_ACTIVE/INT-1").Elements.InsertRow(0,0)
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_ACTIVE/INT-1").Elements.SetLabel(0,0,False,"CS-1")
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_ACTIVE/INT-1").Elements.InsertRow(0,0)
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_ACTIVE/INT-1").Elements.SetLabel(0,0,False,"CS-2")

    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_STAGE1/INT-1/CS-1").Value = 2
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_STAGE2/INT-1/CS-1").Value = feed_stage - 1
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_STAGE1/INT-1/CS-2").Value = feed_stage
    aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/CA_STAGE2/INT-1/CS-2").Value = n_stage - 1

    aspen.Engine.Run2()

    d_1  = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/CA_DIAM6/INT-1/CS-1").Value      # 单位为米
    d_2  = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/CA_DIAM6/INT-1/CS-2").Value      # 单位为米

    return d_1, d_2                                                                           # 单位为米

def determine_d():         # 选择标准塔径与单双溢流

    global n_stage, feed_stage
    n_stage = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/NSTAGE").Value
    feed_stage = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Input/FEED_STAGE/1").Value

    try:
        d_1 = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/CA_DIAM6/INT-1/CS-1").Value   # 单位为米
        d_2 = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/CA_DIAM6/INT-1/CS-2").Value   # 单位为米
    except:
        d_1, d_2 = set_internal()                                          # 单位为米

    d = available_d[available_d > max(d_1, d_2)].min()                                        # 单位为米

    if d in [0.6, 0.7, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0]:
        overflow = "single"                                                                   # 单溢流
    elif d in [2.6, 2.8, 3.0, 3.2, 3.4, 3.6, 3.8, 4.2]:
        overflow = "double"                                                                   # 双溢流
    elif d in [2.2, 2.4] and is_2_overflow:
        overflow = "double"
    else:
        overflow = "single"

    return d, overflow                                                                        # 单位为米
# 输出允许的堰高
def get_outw_h(tray_config, d, overflow):

    if overflow == "double":
        return [50]
    else:
        if "available_heights" in tray_config["weir_height_options"][f"{int(d)}"]:
            available_heights = tray_config["weir_height_options"][f"{int(d)}"]
            return available_heights
        else:
            available_height_low = tray_config["weir_height_options"][f"{int(d)}"]['available_heights_low']
            available_height_high = tray_config["weir_height_options"][f"{int(d)}"]['available_heights_high'] + 0.001
            available_heights = np.arange(available_height_low, available_height_high, 10)
            return available_heights
# 定义塔板
class Standardtray:
    def __init__(self):
        self.tray_type = None                                                   # 溢流类型,single / double
        self.d = 0                                                              # 塔板直径
        self.tower_area = 0                                                     # 塔横截面积
        self.tray_spacing = 0                                                   # 塔板间距
        self.sdc_l = 0                                                          # 侧壁降液管堰长
        self.sdc_h = 0                                                          # 侧壁降液管宽度
        self.cdc_k = 0                                                          # 中心降液管宽度,只有双溢流才有中心降液管
        self.dc_area = 0                                                        # 降液管面积
        self.ad_at = 0                                                          # 降液管面积塔截面积比值
        self.cdc_mass = 0                                                       # 中心降液塔板质量,单溢流没有哦
        self.sdc_mass = 0                                                       # 侧壁降液塔板质量,以后可能算成本,先读了再说
        self.valve_num = 0                                                      # 浮阀个数
        self.open_area = 0                                                      # 开孔率
        self.t = 0                                                              # t值
        self.outw_h = 0                                                         # 出口堰高度
# 生成塔板配置集合
def generate_configurations():
    # 塔板集合
    trays = []
    # 获取塔径与溢流类型
    d, overflow = determine_d()
    d = d * 1000       # 统一度量衡，这里文件有点史山，但是也不能说是史山，因为书上的单位就是毫米，但是我们算数要用米

    if overflow == "single":
        tray_toml_config = "单溢流塔板.toml"
    elif overflow == "double":
        tray_toml_config = "双溢流塔板.toml"

    with open(os.path.abspath(f"{tray_toml_config}"), "rb") as f:
        tray_config = tomllib.load(f)

    tray_spacings = tray_config["tower_diameter"][f"{int(d)}"]['available_tray_spacings']
    dc_options = []
    for i in range(1,4):
        dc_option = tray_config["downcomer_options"][f"{int(d)}"][f"option_{i}"]
        dc_options.append(dc_option)
    available_heights = get_outw_h(tray_config, d, overflow)

    for tray_spacing in tray_spacings:
        for downcomer_params in dc_options:
            sdc_l = downcomer_params[0]
            for i in range(3):
                for available_height in available_heights:

                    valve = tray_config["valve_options"][f"{int(d)}"][f"valve_option_{sdc_l}_{i+1}"]

                    tray = Standardtray()
                    tray.tray_type = overflow                                  # 单位是米
                    tray.d = d / 1000                                          # 单位是米
                    tray.tray_spacing = tray_spacing / 1000                    # 单位是米

                    if overflow == "single":

                        tray.tower_area = tray_config["tower_diameter"][f"{int(d)}"]["cross_sectional_area"]/1e4 #平方米
                        tray.sdc_l = downcomer_params[0] / 1000                # 单位是米
                        tray.sdc_h = downcomer_params[1] / 1000                # 单位是米
                        tray.dc_area = downcomer_params[2] / 10000             # 单位是平方米
                        tray.ad_at = downcomer_params[3]                       # 面积比值，没有单位
                        tray.sdc_mass = downcomer_params[4]                    # 千克
                        tray.valve_num = valve[0]                              # 数量，个
                        tray.open_area = valve[1]                              # 开孔率，没有单位呢
                        tray.t = valve[2]                                      # 这个就不统一度量衡了，毫米
                        tray.outw_h = available_height / 1000                  # 单位是米

                    elif overflow == "double":

                        tray.tower_area = tray_config["tower_diameter"][f"{int(d)}"]["cross_sectional_area"]/1e4 #平方米
                        tray.sdc_l = downcomer_params[0] / 1000                # 单位是米
                        tray.sdc_h = downcomer_params[1] / 1000                # 单位是米
                        tray.cdc_k = downcomer_params[2] / 1000                # 单位是米
                        tray.dc_area = downcomer_params[3] / 10000             # 单位是平方米
                        tray.ad_at = downcomer_params[4]                       # 没有单位
                        tray.sdc_mass = downcomer_params[5]                    # 单位是千克
                        tray.cdc_mass = downcomer_params[6]                    # 单位是千克
                        tray.valve_num = valve[0]                              # 单位是个
                        tray.open_area = valve[1]                              # 没有单位
                        tray.t = valve[2]                                      # 毫米
                        tray.outw_h = available_height / 1000                  # 单位是米

                    trays.append(tray)

    return trays

def get_flooding_rates():
    # 获取每块塔板的液泛率,用以判断确定精馏段和提馏段哪块板负荷最高
    flooding_rates_cs1 = []
    flooding_rates_cs2 = []

    for stage in range(2, feed_stage - 1):
        flood = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/CA_FLD_FAC8/INT-1/CS-1/{stage}").Value
        flooding_rates_cs1.append((stage, flood))

    for stage in range(feed_stage, n_stage):
        flood = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/CA_FLD_FAC8/INT-1/CS-2/{stage}").Value
        flooding_rates_cs2.append((stage, flood))

    max_flood_cs1_stage = max(flooding_rates_cs1, key=lambda x: x[1])
    max_flood_cs2_stage = max(flooding_rates_cs2, key=lambda x: x[1])

    return max_flood_cs1_stage, max_flood_cs2_stage

def get_physical_properties(stage):
    # 获取物性数据
    rou_L = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_RHOL/{stage}").Value             # 液相密度，千克每立方米
    rou_V = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_RHOV/{stage}").Value             # 汽相密度，千克每立方米
    L_VF = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_LVF/{stage}").Value * 3600        # 液相流量，立方米每小时
    V_VF = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_VVF/{stage}").Value * 3600        # 汽相流量，立方米每小时
    mu_L = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_MUL/{stage}").Value * 1000        # 液相黏度，厘泊
    mu_V = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_MUV/{stage}").Value * 1000        # 汽相黏度，厘泊
    sigma = aspen.Tree.FindNode(f"/Data/Blocks/{block}/Output/HYD_STEN/{stage}").Value * 1000      # 液相表面张力，毫牛每米

    print(f"精馏段/提馏段最高负荷塔板的液相黏度为{mu_L}厘泊，可以拿来计算全塔效率")
    properties = np.array([rou_L, rou_V, L_VF, V_VF, mu_L, mu_V, sigma])

    return properties
# 获取三个图的结果，包括泛点负荷因数，充气系数，液流收缩系数
def predict_from_model(pth_path, x, y):
    # 重建全连接神经网络
    class SimpleModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(2, 32),
                nn.ReLU(),
                nn.Linear(32, 16),
                nn.ReLU(),
                nn.Linear(16, 16),
                nn.ReLU(),
                nn.Linear(16, 16),
                nn.ReLU(),
                nn.Linear(16, 1)
            )
        def forward(self, z):
            return self.net(z)
    model = SimpleModel()
    model.load_state_dict(torch.load(pth_path))
    model.eval()
    input_data = torch.tensor([[x, y]], dtype=torch.float32)
    with torch.no_grad():
        prediction = model(input_data)
    # 返回拟合结果
    return prediction.item()
# 计算操作线
def calculate_operating_lines(tray, properties):

    rou_L = properties[0]                         # 液相密度，千克每立方米
    rou_V = properties[1]                         # 汽相密度，千克每立方米
    L_VF = properties[2]                          # 液相流量，立方米每小时
    V_VF = properties[3]                          # 汽相流量，立方米每小时
    mu_L = properties[4]                          # 液相黏度，厘泊
    mu_V = properties[5]                          # 汽相黏度，厘泊
    sigma = properties[6]                         # 液相表面张力，毫牛每米

    tray_type = tray.tray_type                    # 溢流类型
    d = tray.d                                    # 塔板直径，米
    l_w = tray.sdc_l                              # 侧壁降液管堰长，米
    w_d = tray.sdc_h                              # 侧壁降液管堰宽，米
    h_T = tray.tray_spacing                       # 塔板间距
    h_w = tray.outw_h                             # 堰高
    n_o = tray.valve_num                          # 阀孔数量
    d_o = 39                                      # 阀孔直径，F1型浮阀直径都是39毫米，具体请看国标
    a_T = tray.tower_area                         # 塔板面积
    a_d = tray.dc_area                            # 降液管面积

    if tray_type == "single":
        a_b = a_T - 2 * a_d                       # 液流面积
        z = d - 2 * w_d                           # 液相流程长
    else:
        l_w += l_w                                # 双溢流有两个侧壁降液管，所以后续计算应使用两个侧壁降液管堰长之和
        w_d_2 = tray.cdc_k                        # 中心降液管堰宽，米
        r = d / 2
        z = 1 / 2 * (d - 2 * w_d - w_d_2)         # 液相流程长
        cdc_area = r ** 2 * 2 * np.arcsin(w_d_2 / d) + w_d_2 * np.sqrt(r ** 2 - (w_d_2 / 2) ** 2)         # 中心降液管面积
        sdc_area = r ** 2 * np.arccos((r - w_d) / r) - (r - w_d) * np.sqrt(2 * r * w_d - w_d ** 2)        # 侧壁降液管面积
        a_b = a_T - 2 * sdc_area - cdc_area       # 液流面积

    c_f = predict_from_model(pth_path = "浮阀塔板泛点负荷因数图.pth", x = h_T, y = rou_V)                     # 泛点负荷因数
    e_1 = predict_from_model(pth_path = "液流收缩系数图.pth", x = 0.225 * L_VF / (l_w ** 2.5), y = l_w / d)   # 液流收缩系数
    h_ow = 0.00284 * e_1 * (L_VF / l_w) ** (2 / 3)                                                        # 堰上液层高度
    h_l = h_ow + h_w
    beta_w = predict_from_model(pth_path = "充气系数图.pth", x = h_l, y = f_o)
    beta = beta_w * (sigma / 73) ** 0.15                                                                  # 充气系数

    def fog_line_a(l_h):
        # 过量雾沫夹带线a
        return np.sqrt((rou_L - rou_V) / rou_V) * (3600 * f_1 * a_b * k_s * c_f - 1.36 * l_h * z)
    def fog_line_b(l_h):
        # 过量雾沫夹带线b
        return 2300 * a_T * k_s * c_f * np.sqrt((rou_L - rou_V) / rou_V)
    def fog_line_c(l_h):
        # 过量雾沫夹带线c
        phi = 0.8
        e_v = 0.1
        A = 0.159 # if h_T >= 0.4 else 9.48e7
        n = 0.95 # if h_T >= 0.4 else 4.36
        m = 5.63e-5 * (sigma / rou_V) ** 0.295 * ((rou_L - rou_V) / (mu_V * 1.02e-4) ** 0.425)
        a_1 = A / h_T ** n / phi ** 2
        b_1 = 52 * h_w - 1.72 + 0.14768 * e_1 * (l_h / l_w) ** (2 / 3)
        c_1 = (353.68 / d_o ** 2 / n_o / m) ** 3.7
        return (e_v / (a_1 * b_1 * c_1)) ** 0.2703
    def flood_line(l_h):
        # 淹塔线
        a_2 = 34236.4 / (d_o ** 4) * rou_V / (n_o ** 2) / rou_L
        b_2 = phi_2 * h_T + (phi_2 - 1 - beta) * h_w
        if receiving_pan == "凹形":
            c_2 = 1.952e-8 / (l_w ** 2) / ((h_w - 0.006) ** 2)
        else:
            c_2 = 1.18e-8 / (l_w ** 2) / ((h_w - 0.006) ** 2)
        d_2 = 0.00284 * e_1 * (1 + beta) / (l_w ** (2 / 3))
        return np.sqrt(np.maximum(((b_2 - c_2 * (l_h ** 2) - d_2 * (l_h ** (2 / 3))) / a_2), 0))
    def leak_line(l_h):
        # 过量泄露线
        return 0.00282744 * d_o ** 2 * f_o * n_o / np.sqrt(rou_V)
    # 降液管超负荷线
    l_h_max = 3600 * a_d * h_T / tao
    # 液相负荷下限线
    l_h_min = (2.113 / e_1) ** 1.5 * l_w
    if choose_fog_line == "A":
        fog_line = fog_line_a
    elif choose_fog_line == "B":
        fog_line = fog_line_b
    else:
        fog_line = fog_line_c
    operating_lines = {
        'fog_line': fog_line,
        'flood': flood_line,
        'leak': leak_line,
        'l_h_max': l_h_max,
        'l_h_min': l_h_min
    }
    return operating_lines

def check_operating_point(properties, operating_lines):
    # 检查操作点是否在性能图内
    L_VF = properties[2]                          # 液相流量，立方米每小时
    V_VF = properties[3]                          # 汽相流量，立方米每小时
    operating_state = []
    state = 0
    # 检查是否在过量雾沫夹带线之下
    V_h_fog = operating_lines['fog_line'](L_VF)
    if V_VF >= V_h_fog:
        operating_state.append(f"过量雾沫夹带线之上 (V_VF={V_VF:.2f} >= {V_h_fog:.2f}")
    else:
        state += 1
    # 检查是否在淹塔线之下
    V_h_flood = operating_lines['flood'](L_VF)
    if V_VF >= V_h_fog:
        operating_state.append(f"淹塔线之上 (V_VF={V_VF:.2f} >= {V_h_flood:.2f})")
    else:
        state += 1
    # 检查是否在过量泄露线之上
    V_h_leak = operating_lines['leak'](L_VF)
    if V_VF <= V_h_leak:
        operating_state.append(f"过量泄露线之下 (V_VF={V_VF:.2f} <= {V_h_leak:.2f})")
    else:
        state += 1
    # 检查是否在降液管超负荷线之左
    l_h_max = operating_lines['l_h_max']
    if L_VF >= l_h_max:
        operating_state.append(f"降液管超负荷线之右 (L_VF={L_VF:.2f} >= {l_h_max:.2f})")
    else:
        state += 1
    # 检查是否在液相负荷下限线之右
    l_h_min = operating_lines['l_h_min']
    if L_VF <= l_h_min:
        operating_state.append(f"液相负荷下限线之左 (L_VF={L_VF:.2f} <= {l_h_min:.2f})")
    else:
        state += 1
    return operating_state, state

def calculate_operating_elasticity(properties, operating_lines):
    # 计算操作弹性
    L_VF = properties[2]                          # 液相流量，立方米每小时
    V_VF = properties[3]                          # 汽相流量，立方米每小时
    # 操作线斜率
    slope = V_VF / L_VF
    # L一定要在液相负荷下限线和降液管超负荷线之间
    L_test_min = operating_lines['l_h_min'] / 0.7
    L_test_max = operating_lines['l_h_max'] * 1.5
    L_test = np.linspace(L_test_min, L_test_max, 100)
    # 操作线与过量泄露线的交点 / 下限类线
    V_leak = operating_lines['leak'](L_VF)
    # 操作线与液相负荷下限线的交点 / 下限类线
    L_min = operating_lines['l_h_min']
    V_min = L_min * slope
    # 操作线与过量雾沫夹带线的交点 / 上限类线
    def find_intersection_fog(l):
        return operating_lines['fog_line'](l) - slope * l
    fog_vals = [find_intersection_fog(l) for l in L_test]
    fog_sign_changes = np.where(np.diff(np.sign(fog_vals)))[0]
    if len(fog_sign_changes) > 0:
        idx = fog_sign_changes[0]
        L_fog = L_test[idx]
        V_fog = slope * L_fog
    else:
        L_fog = L_test[99]
        V_fog = slope * L_fog
    # 操作线与淹塔线的交点 / 上限类线
    def find_intersection_flood(l):
        return operating_lines['flood'](l) - slope * l
    flood_vals = [find_intersection_flood(l) for l in L_test]
    flood_sign_changes = np.where(np.diff(np.sign(flood_vals)))[0]
    if len(flood_sign_changes) > 0:
        idx = flood_sign_changes[0]
        L_flood = L_test[idx]
        V_flood = slope * L_flood
    # 操作线与降液管超负荷线的交点 / 上限类线
    L_max = operating_lines['l_h_max']
    V_max = L_max * slope

    V_operating_min = max(V_min, V_leak)
    V_operating_max = min(V_fog, V_flood, V_max)
    elasticity = V_operating_max / V_operating_min
    return elasticity, V_operating_min, V_operating_max
# 绘图
def plot_load_performance(properties,operating_lines,elasticity,v_operating_min
                          ,v_operating_max,section_name,config_id,state):

    plt.rcParams['font.sans-serif'] = ['SimHei']                          # 中文字体
    plt.figure(figsize=(12, 10))                                          # 图片大小

    L_VF = properties[2]                          # 液相流量，立方米每小时
    V_VF = properties[3]                          # 汽相流量，立方米每小时
    L_h_min = max(operating_lines['l_h_min'] * 0.7, 0.1)
    L_h_max = operating_lines['l_h_max'] * 1.3
    L_h_range = np.linspace(L_h_min, L_h_max, 200)

    colors = ['red', 'blue', 'green', 'purple', 'orange',]
    line_names = ['过量雾沫夹带线', '淹塔线', '过量泄露线', '降液管超负荷线','液相负荷下限线']
    line_styles = ['-', '--', '-.', ':', '-']

    # 绘制过量雾沫夹带线
    V_h_fog = [operating_lines['fog_line'](L) for L in L_h_range]
    plt.plot(L_h_range, V_h_fog, color=colors[0], linestyle=line_styles[0],
             label=line_names[0], linewidth=2)
    # 绘制淹塔线
    V_h_flood = [operating_lines['flood'](L) for L in L_h_range]
    plt.plot(L_h_range, V_h_flood, color=colors[1], linestyle=line_styles[1],
             label=line_names[1], linewidth=2)
    # 绘制过量泄露线
    V_h_leak = [operating_lines['leak'](L) for L in L_h_range]
    plt.plot(L_h_range, V_h_leak, color=colors[2], linestyle=line_styles[2],
             label=line_names[2], linewidth=2)
    # 绘制降液管超负荷线
    L_h_overflow = operating_lines['l_h_max']
    plt.axvline(x=L_h_overflow, color=colors[3], linestyle=line_styles[3],
             label=line_names[3], linewidth=2)
    # 绘制液相负荷下限线
    L_h_min_line = operating_lines['l_h_min']
    plt.axvline(x=L_h_min_line, color=colors[4], linestyle=line_styles[4],
             label=line_names[4], linewidth=2)
    # 绘制操作线
    slope = V_VF / L_VF
    V_h_op = [slope * L for L in L_h_range]
    plt.plot(L_h_range, V_h_op, 'k-', label='操作线', linewidth=3)
    # 绘制操作点
    plt.plot(L_VF, V_VF, 'r*', markersize=15, label='操作点', markeredgewidth=2)
    # 绘制边界点
    l_operating_min = v_operating_min / slope
    l_operating_max = v_operating_max / slope
    plt.plot(l_operating_min, v_operating_min, 'ro', markersize=10,label='操作下限点', markeredgewidth=2)
    plt.plot(l_operating_max, v_operating_max, 'ro', markersize=10,label='操作上限点', markeredgewidth=2)
    # 给坐标轴命名
    plt.xlabel('液相负荷 L_h (cum/h)', fontsize=12)
    plt.ylabel('气相负荷 V_h (cum/h)', fontsize=12)
    # 设置标题
    plt.title(f'配置{config_id} - {section_name}负荷性能图'
              f'/n操作弹性: {elasticity:.2f}',
              fontsize=14, fontweight='bold')
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.xlim(L_h_min, L_h_max)
    # 保存图片
    plt.savefig(os.path.join(os.getcwd(), "图", f"{state}", f"配置{config_id}_{section_name}负荷性能图.png"),
                dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

    return 0
# 主进程
def run_analysis():
    # 获取塔板配置
    trays = generate_configurations()
    # 建立日志文件
    log_wb = Workbook()
    log_ws = log_wb.active
    log_ws.title = "浮阀塔标准塔板状态检查日志"
    headers = ["塔板编号", "精馏段/提馏段状态", "塔径(mm)", "塔板间距(mm)", "侧壁降液管堰长(mm)", "浮阀数", "t值", "堰高(mm)",
               "精馏段最高液泛率塔板", "提馏段最高液泛率塔板",
               "精馏段液相负荷(cum/hr)", "精馏段气相负荷(cum/hr)", "提馏段液相负荷(cum/hr)", "提馏段气相负荷(cum/hr)",
               "精馏段操作点状态", "提馏段操作点状态", "精馏段操作弹性", "提馏段操作弹性",]
    for col, header in enumerate(headers, 1):
        log_ws.cell(row=1, column=col, value=header)
    log_row = 2
    # 获取液泛率最高的塔板
    cs1_stage, cs2_stage = get_flooding_rates()
    # 获取液泛率最高的塔板的一系列参数
    properties_1 = get_physical_properties(cs1_stage)           # 精馏段
    properties_2 = get_physical_properties(cs2_stage)           # 提馏段
    for i, tray in enumerate(trays):
        # 计算五条操作线
        operating_lines_1 = calculate_operating_lines(tray, properties_1)
        operating_lines_2 = calculate_operating_lines(tray, properties_2)
        # 检查操作点是否在五条操作线之内
        operating_state_1, state_1 = check_operating_point(properties_1, operating_lines_1)
        operating_state_2, state_2 = check_operating_point(properties_2, operating_lines_2)
        is_qualified_1 = state_1 == 5
        is_qualified_2 = state_2 == 5
        status_1 = "合格" if is_qualified_1 else "不合格"
        status_2 = "合格" if is_qualified_2 else "不合格"
        # 计算操作弹性
        if status_1 == "合格":
            ela_1, V_min_1, V_max_1 = calculate_operating_elasticity(properties_1, operating_lines_1)
        else:
            ela_1, V_min_1, V_max_1 = 0, 0, 0
        if status_2 == "合格":
            ela_2, V_min_2, V_max_2 = calculate_operating_elasticity(properties_2, operating_lines_2)
        else:
            ela_2, V_min_2, V_max_2 = 0, 0, 0
        # 生成png图
        png_1 = plot_load_performance(properties_1,operating_lines_1,ela_1,V_min_1,V_max_1,"精馏段",i + 1,status_1)
        png_2 = plot_load_performance(properties_2,operating_lines_2,ela_2,V_min_2,V_max_2,"提馏段",i + 1,status_2)
        # 记录日志
        log_ws.cell(row=log_row, column=1, value=i + 1)                                            # 塔板编号
        log_ws.cell(row=log_row, column=2, value=f"{status_1}/{status_2}")                         # 精馏段/提馏段状态
        log_ws.cell(row=log_row, column=3, value=int(tray.d * 1000))                               # 塔径,毫米
        log_ws.cell(row=log_row, column=4, value=int(tray.tray_spacing * 1000))                    # 塔板间距,毫米
        log_ws.cell(row=log_row, column=5, value=int(tray.sdc_l * 1000))                           # 侧壁降液管堰长,毫米
        log_ws.cell(row=log_row, column=6, value=int(tray.valve_num))                              # 浮阀个数
        log_ws.cell(row=log_row, column=7, value=int(tray.t))                                      # t值
        log_ws.cell(row=log_row, column=8, value=int(tray.outw_h * 1000))                          # 出口堰高度,毫米
        log_ws.cell(row=log_row, column=9, value=int(cs1_stage[0]))                                # 精馏段最高液泛率塔板
        log_ws.cell(row=log_row, column=10, value=int(cs2_stage[0]))                               # 提馏段最高液泛率塔板
        log_ws.cell(row=log_row, column=11, value=float(properties_1[2]))                          # 精馏段液相负荷,cum/hr
        log_ws.cell(row=log_row, column=12, value=float(properties_1[3]))                          # 精馏段汽相负荷,cum/hr
        log_ws.cell(row=log_row, column=13, value=float(properties_2[2]))                          # 提馏段液相负荷,cum/hr
        log_ws.cell(row=log_row, column=14, value=float(properties_2[3]))                          # 提馏段汽相负荷,cum/hr
        log_ws.cell(row=log_row, column=15, value=str(operating_state_1))                          # 精馏段操作点状态
        log_ws.cell(row=log_row, column=16, value=str(operating_state_2))                          # 提馏段操作点状态
        log_ws.cell(row=log_row, column=17, value=float(ela_1) if ela_1 is not None else "N/A")    # 精馏段操作弹性
        log_ws.cell(row=log_row, column=18, value=float(ela_2) if ela_2 is not None else "N/A")    # 提馏段操作弹性

        log_row += 1

    log_path = os.path.join(os.getcwd(), "浮阀塔标准塔板状态检查日志.xlsx")
    log_wb.save(log_path)

    return 0

tower_valve = run_analysis()
aspen.Close()